<?php
    function smarty_modifier_rot13($str, $args) {
        if ($args != 1) {
            return $str;
        }

        return str_rot13($str);
    }
?>
