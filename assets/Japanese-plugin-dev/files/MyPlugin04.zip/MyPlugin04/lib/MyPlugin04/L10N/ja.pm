package MyPlugin04::L10N::ja;

use strict;
use base 'MyPlugin04::L10N::en_us';
use vars qw( %Lexicon );

%Lexicon = (
    'Sample Plugin rot13 globale modifier' => 'サンプルプラグイン rot13 グローバル・モディファイア',
    '_PLUGIN_DESCRIPTION' => 'rot13 テストプラグイン',
    '_PLUGIN_AUTHOR' => 'プラグイン作者',
);

1;
