package MyPlugin04::Tags;
use strict;

sub _hdlr_rot13 {
    my ($str, $arg, $ctx) = @_;
    return $str if $arg != 1;

    $str =~ tr/a-zA-Z/n-za-mN-ZA-M/;

    return $str;
}

1;
