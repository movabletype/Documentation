package MyPlugin16::L10N::ja;

use strict;
use base 'MyPlugin16::L10N::en_us';
use vars qw( %Lexicon );

%Lexicon = (
    'Modal Window' => 'モーダルウィンドウ',
    'Sample Plugin Modal Window' => 'サンプルプラグイン モーダルウィンドウ',
    '_PLUGIN_DESCRIPTION' => 'モーダルウィンドウ テストプラグイン',
    '_PLUGIN_AUTHOR' => 'プラグイン作者',
);

1;
