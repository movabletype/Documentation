package MyPlugin14::L10N::ja;

use strict;
use base 'MyPlugin14::L10N::en_us';
use vars qw( %Lexicon );

%Lexicon = (
    'New Menu' => '新規メニュー',
    'Sample Plugin Transformer' => 'サンプルプラグイン トランスフォーマー',
    '_PLUGIN_DESCRIPTION' => '独自オブジェクト トランスフォーマー',
    '_PLUGIN_AUTHOR' => 'プラグイン作者',
);

1;
