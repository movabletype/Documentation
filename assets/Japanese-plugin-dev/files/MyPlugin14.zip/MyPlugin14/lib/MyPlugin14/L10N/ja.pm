package MyPlugin14::L10N::ja;

use strict;
use base 'MyPlugin14::L10N::en_us';
use vars qw( %Lexicon );

%Lexicon = (
    'New Menu' => '新規メニュー',
    'Sample Plugin Menu Customize' => 'サンプルプラグイン 管理画面メニュー',
    '_PLUGIN_DESCRIPTION' => '管理画面メニュー テストプラグイン',
    '_PLUGIN_AUTHOR' => 'プラグイン作者',
);

1;
