<?php
    function smarty_block_mtcategoryiftoplevel ($args, $content, &$ctx, &$repeat) {
        if (!isset($content)) {
            $entry = $ctx->stash('entry');
            $cat = $entry->category();
            if (!$cat) {
                $flag = 0;
            } else {
                if ($cat->parent == 0) {
                    $flag = 1;
                } else {
                    $flag = 0;
                }
            }
            return $ctx->_hdlr_if($args, $content, $ctx, $repeat, $flag);
        } else {
            return $ctx->_hdlr_if($args, $content, $ctx, $repeat);
        }
    }
?>
