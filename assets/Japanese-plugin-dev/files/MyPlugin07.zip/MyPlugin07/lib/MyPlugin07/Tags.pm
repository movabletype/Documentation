package MyPlugin07::Tags;
use strict;

sub hdlr_category_if_toplevel {
    my ($ctx, $args, $cond) = @_;

    my $entry = $ctx->stash('entry');
    my $cat = $entry->category() || return 0;

    return ($cat->parent() == 0);
}

1;
