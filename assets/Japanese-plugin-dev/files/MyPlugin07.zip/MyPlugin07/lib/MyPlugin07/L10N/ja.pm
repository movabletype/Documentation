package MyPlugin07::L10N::ja;

use strict;
use base 'MyPlugin07::L10N::en_us';
use vars qw( %Lexicon );

%Lexicon = (
    'Sample Plugin Conditional tag' => 'サンプルプラグイン コンディショナルタグ',
    '_PLUGIN_DESCRIPTION' => 'コンディショナルタグ テストプラグイン',
    '_PLUGIN_AUTHOR' => 'プラグイン作者',
);

1;
