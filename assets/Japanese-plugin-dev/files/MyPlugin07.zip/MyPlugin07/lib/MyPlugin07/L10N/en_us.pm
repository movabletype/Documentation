package MyPlugin07::L10N::en_us;

use strict;
use base 'MyPlugin07::L10N';
use vars qw( %Lexicon );

%Lexicon = (
    '_PLUGIN_DESCRIPTION' => 'Sample conditional tag',
    '_PLUGIN_AUTHOR' => 'Plugin author',
);

1;
