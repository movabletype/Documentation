package MyPlugin10::L10N::en_us;

use strict;
use base 'MyPlugin10::L10N';
use vars qw( %Lexicon );

%Lexicon = (
    '_PLUGIN_DESCRIPTION' => 'Sample scheduled task plugin',
    '_PLUGIN_AUTHOR' => 'Plugin author',
);

1;

