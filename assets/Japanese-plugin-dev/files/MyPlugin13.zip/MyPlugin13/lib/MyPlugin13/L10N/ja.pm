package MyPlugin13::L10N::ja;

use strict;
use base 'MyPlugin13::L10N::en_us';
use vars qw( %Lexicon );

%Lexicon = (
    'Sample Plugin Transformer' => 'サンプルプラグイン トランスフォーマー',
    '_PLUGIN_DESCRIPTION' => 'トランスフォーマー テストプラグイン',
    '_PLUGIN_AUTHOR' => 'プラグイン作者',
);

1;
