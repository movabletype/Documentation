package MyPlugin13::Transformer;
use strict;

sub hdlr_template_source_edit_entry {
    my ($cb, $app, $tmpl_ref) = @_;
    my $old = <<EOF;
                        <div class="tab" mt:command="set-editor-extended" mt:tab="extended">
                            <label><a href="javascript:void(0);"><__trans phrase="Extended"></a></label>
                        </div>
EOF
    $old = quotemeta($old);
    $old =~ s!(\\ )+!\\s+!g;

    my $new = "";

    $$tmpl_ref =~ s!$old!$new!;
}

sub hdlr_template_output_edit_entry {
    my ($cb, $app, $tmpl_str_ref, $param, $tmpl) = @_;

    # do something
}

sub hdlr_template_param_edit_entry {
    my ($cb, $app, $param, $tmpl) = @_;

    my $host_node = $tmpl->getElementById('keywords');
    my $innerHTML = '<input type="text" name="url_field" id="url_field" class="full-width" mt:watch-change="1" value="<mt:var name="url_field" escape="html">" autocomplete="off" />';

    my $block_node = $tmpl->createElement(
        'app:setting',
        {
            id => 'url_field',
            label => 'URL',
            label_class => 'top-label',
        }
    );

    $block_node->innerHTML( $innerHTML );
    $tmpl->insertAfter($block_node, $host_node);

    $param->{url_field} = "http://www.example.com/" if !$param->{url_field};
}

1;
