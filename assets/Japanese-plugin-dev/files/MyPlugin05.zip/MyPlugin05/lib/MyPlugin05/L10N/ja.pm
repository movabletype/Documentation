package MyPlugin05::L10N::ja;

use strict;
use base 'MyPlugin05::L10N::en_us';
use vars qw( %Lexicon );

%Lexicon = (
    'Sample Plugin function tag' => 'サンプルプラグイン ファンクションタグ',
    '_PLUGIN_DESCRIPTION' => 'ファンクションタグ テストプラグイン',
    '_PLUGIN_AUTHOR' => 'プラグイン作者',
);

1;
