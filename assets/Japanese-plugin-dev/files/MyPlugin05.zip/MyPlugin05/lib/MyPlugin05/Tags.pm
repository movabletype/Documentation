package MyPlugin05::Tags;
use strict;

sub _hdlr_cssbycategory {
    my ($ctx, $args) = @_;

    my $entry = $ctx->stash('entry')
        || $ctx->error(MT->translate('You used an [_1] tag outside of the proper context.', 'CSSByCategory'));

    my $cat = $entry->category() || return;

    my @basenames = ();
    while (1){
         if ($cat->parent() == 0) {
             push (@basenames, $cat->basename());
             last;
         }
         push (@basenames, $cat->basename());
         $cat = MT::Category->load($cat->parent());
    }

    my $cat_tmp = 'cat-' . (join '-', reverse @basenames);
    $cat_tmp .= '/screen.css';

    my $mt = MT->instance;
    my $css_dir = $mt->config('StaticWebPath') || '/mt-static/';
    unless ($css_dir =~ m/\/$/) {
        $css_dir .= '/';
    }
    $css_dir .= 'support/css/';

    return '<link rel="stylesheet" href="' . $css_dir . $cat_tmp . '" type="text/css" />';
}

1;
