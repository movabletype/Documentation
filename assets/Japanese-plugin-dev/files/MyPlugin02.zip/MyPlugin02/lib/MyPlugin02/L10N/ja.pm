# Sample Plugin: Plugin L10N

package MyPlugin02::L10N::ja;

use strict;
use base 'MyPlugin02::L10N::en_us';
use vars qw( %Lexicon );

%Lexicon = (
    'Sample plugin L10N' => 'サンプルプラグイン L10N',
    '_PLUGIN_DESCRIPTION' => 'サンプルプラグイン L10N',
    '_PLUGIN_AUTHOR' => 'プラグイン作者',
);

1;

