package MyPlugin02::L10N::en_us;

use strict;
use base 'MyPlugin02::L10N';
use vars qw( %Lexicon );

%Lexicon = (
    '_PLUGIN_DESCRIPTION' => 'Sample plugin L10N',
    '_PLUGIN_AUTHOR' => 'Plugin author',
);

1;
