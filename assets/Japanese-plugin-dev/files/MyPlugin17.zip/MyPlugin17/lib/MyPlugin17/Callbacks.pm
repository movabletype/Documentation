package MyPlugin17::Callbacks;
use strict;

use constant YAHOO_API_URI => 'http://jlp.yahooapis.jp/KeyphraseService/V1/extract';
use constant TAG_SCORE => 50;

sub post_save_entry {
    my ($cb, $app, $obj, $org_obj) = @_;
    my $plugin = MT->component('MyPlugin17');

    my $api_id = $plugin->get_config_value('yahoo_japan_api_id', 'system');
    return 1 unless $api_id;

    require LWP::UserAgent;
    require HTTP::Request::Common;

    my $text = $obj->title . ' ' . $obj->text . ' ' . $obj->text_more;
    my %data = ( 'appid' => $api_id,
                 'sentence' => $text,
               );
    my $req = HTTP::Request::Common::POST(YAHOO_API_URI, [%data]);
    my $ua = LWP::UserAgent->new;
    my $res = $ua->request($req);

    require XML::Simple;
    my $results = XML::Simple::XMLin($res->content)->{'Result'};

    my @tags = ();
    foreach my $i (0..$#$results) {
        my $result = $results->[$i];
        my $score = $result->{'Score'};
        my $keyphrase = $result->{'Keyphrase'};
        push(@tags, $keyphrase) if $score >= TAG_SCORE;
    }
    return 1 unless @tags;

    $obj->add_tags(@tags);
    $obj->save
        or die $obj->errstr;
}

1;

