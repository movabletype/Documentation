package MyPlugin17::L10N::ja;

use strict;
use base 'MyPlugin17::L10N::en_us';
use vars qw( %Lexicon );

%Lexicon = (
    'Please input the Yahoo! Japan API ID.' => 'Yahoo! Japan の API ID を入力してください。',
    'Sample Plugin API' => 'サンプルプラグイン 外部API連携',
    '_PLUGIN_DESCRIPTION' => '外部API連携 テストプラグイン',
    '_PLUGIN_AUTHOR' => 'プラグイン作者',
);

1;
