package MyPlugin12::L10N::ja;

use strict;
use base 'MyPlugin12::L10N::en_us';
use vars qw( %Lexicon );

%Lexicon = (
    'Sample Plugin New Application' => 'サンプルプラグイン 新規アプリケーション',
    '_PLUGIN_DESCRIPTION' => '独自オブジェクト 新規アプリケーション',
    '_PLUGIN_AUTHOR' => 'プラグイン作者',
);

1;
