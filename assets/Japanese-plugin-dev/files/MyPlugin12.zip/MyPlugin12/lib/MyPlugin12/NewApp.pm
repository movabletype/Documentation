package MyPlugin12::NewApp;
use strict;

use base qw( MT::App );

sub init_request {
    my $app = shift;
    $app->SUPER::init_request(@_);
    $app->add_methods( main => \&view,
                       view => \&view,
                       new  => \&foo_new,
                       edit => \&edit,
                       save => \&save,
                     );
    $app->{ default_mode }   = 'main';
    $app->{ requires_login } = 1;
}

sub view {
    my $app = shift;
    my $q = $app->param;
    my $blog_id = $q->param('blog_id');
    my $blog = MT->model('blog')->load($blog_id);
    my $class = $app->model('foo');
    my ( $terms, $args );
    $terms = { blog_id => $blog_id };
    $args  = { sort      => 'created_on',
               direction => 'descend',
               limit     => 10,
             };
    my @foos = $class->load( $terms, $args );
    my $param;
    $param = { blog_name   => $blog->name,
               foos        => \@foos,
               plugin_template_path => 'tmpl',
             };
    $app->build_page( 'view_foo.tmpl', $param );
}

sub edit {
    my $app = shift;
    my $q = $app->param;
    my $blog_id = $q->param('blog_id');
    my $blog = MT->model('blog')->load($blog_id);
    my $id = $q->param('id');
    my $class = $app->model('foo');
    my $foo = $class->load( $id );
    my $param;
    $param = { blog_name   => $blog->name,
               id      => $id,
               blog_id => $blog_id,
               title   => $foo->title(),
               bar     => $foo->bar(),
               plugin_template_path => 'tmpl',
             };
    $app->build_page( 'edit_foo.tmpl', $param );
}

sub save {
    my $app = shift;
    my $q = $app->param;
    my $blog_id = $q->param('blog_id');
    my $blog = MT->model('blog')->load($blog_id);
    my $class = $app->model('foo');
    my $foo;
    my $id;
    if ( $id = $q->param('id') ) {
        $foo = $class->load($id);
    } else {
        $foo = $class->new();
        $foo->blog_id($blog_id);
    }

    $foo->title($q->param('title'));
    $foo->bar($q->param('bar'));

    $foo->save()
        or die $foo->errstr;

    $app->redirect( $app->return_uri . "blog_id=$blog_id" );
}

sub foo_new {
    my $app = shift;
    my $q = $app->param;
    my $blog_id = $q->param('blog_id');
    my $blog = MT->model('blog')->load($blog_id);

    my $param = { blog_name => $blog->name,
                  blog_id   => $blog_id,
                };

    $app->build_page( 'new_foo.tmpl', $param );
}

1;

