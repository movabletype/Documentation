<?php
$lang = substr(strtolower($this->config('DefaultLanguage')), 0, 2);
if (!@include_once("lib/l10n_$lang.php")) {
    include_once("lib/l10n_en.php");
}
?>
