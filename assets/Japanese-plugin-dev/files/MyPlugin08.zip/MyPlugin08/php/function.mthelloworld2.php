<?php
    function smarty_function_mthelloworld2($args, &$ctx) {
        $mt = MT::get_instance();
        $blog_id = 'blog:' . $ctx->stash('blog_id');

        $cfg = $mt->db()->fetch_plugin_data('MyPlugin08', 'configuration:' . $blog_id);
        $word_blog = $cfg['word_setting_blog'];

        $cfg = $mt->db()->fetch_plugin_data('MyPlugin08', 'configuration');
        $word_sys = $cfg['word_setting_system'];

        $word_default = $mt->translate('world');

        $word = $word_blog ? $word_blog :
                  ( $word_sys ? $word_sys : $word_default );

        return $mt->translate( 'Hello, [_1]!', $word );
    }
?>

