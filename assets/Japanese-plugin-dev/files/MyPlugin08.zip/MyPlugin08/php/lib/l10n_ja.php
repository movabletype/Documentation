<?php
global $Lexicon_ja;
$Lexicon_ja = array(
    'world' => '世界',
    'Hello, [_1]!' => 'こんにちは、[_1]！',
);
?>
