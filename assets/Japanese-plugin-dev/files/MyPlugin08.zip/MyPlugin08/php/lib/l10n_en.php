<?php
global $Lexicon_en;
$Lexicon_en = array(
);
?>
