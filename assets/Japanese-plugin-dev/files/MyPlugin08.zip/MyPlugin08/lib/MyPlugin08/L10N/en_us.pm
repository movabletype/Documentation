package MyPlugin08::L10N::en_us;

use strict;
use base 'MyPlugin08::L10N';
use vars qw( %Lexicon );

%Lexicon = (
    '_PLUGIN_DESCRIPTION' => 'Sample Test Driven test plugin',
    '_PLUGIN_AUTHOR' => 'Plugin author',

    '_MyPlugin08_Word' => 'Word',
);

1;

