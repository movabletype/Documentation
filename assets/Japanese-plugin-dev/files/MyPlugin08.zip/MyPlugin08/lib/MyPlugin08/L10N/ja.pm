package MyPlugin08::L10N::ja;

use strict;
use base 'MyPlugin08::L10N::en_us';
use vars qw( %Lexicon );

%Lexicon = (
    'Sample Plugin plugin config' => 'サンプルプラグイン プラグイン設定',
    '_PLUGIN_DESCRIPTION' => 'プラグイン設定 テストプラグイン',
    '_PLUGIN_AUTHOR' => 'プラグイン作者',

    '_MyPlugin08_Word' => '言葉',
    'Please input the word, \'Hello, xxx!\'', => '表示させたい言葉を入力してください。\'こんにちは、xxx！\'',
    'Hello, [_1]!' => 'こんにちは、[_1]！',
    'world' => '世界',
);

1;
