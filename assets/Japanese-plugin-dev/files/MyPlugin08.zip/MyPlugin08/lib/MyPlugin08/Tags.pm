package MyPlugin08::Tags;
use strict;

sub _hdlr_hello_world_2 {
    my ($ctx, $args) = @_;
    my $blog_id = 'blog:' . $ctx->stash('blog_id');
    my $plugin = MT->component('MyPlugin08');

    my $word_blog = $plugin->get_config_value('word_setting_blog', $blog_id);
    my $word_sys = $plugin->get_config_value('word_setting_system', 'system');

    my $word_default = MT->translate('world');

    my $word = $word_blog ? $word_blog :
                 ( $word_sys ? $word_sys : $word_default );

    return MT->translate( 'Hello, [_1]!', $word );
}

1;
