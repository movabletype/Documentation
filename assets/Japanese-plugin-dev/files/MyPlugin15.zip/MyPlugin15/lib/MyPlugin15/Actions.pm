package MyPlugin15::Actions;
use strict;

sub hndl_author_language_ja {
    my $app = shift;
    _set_author_language($app, 'ja');
}

sub hndl_author_language_en_US {
    my $app = shift;
    _set_author_language($app, 'en_US');
}

sub hndl_author_language_de {
    my $app = shift;
    _set_author_language($app, 'de');
}

sub hndl_author_language_es {
    my $app = shift;
    _set_author_language($app, 'es');
}

sub hndl_author_language_fr {
    my $app = shift;
    _set_author_language($app, 'fr');
}

sub hndl_author_language_nl {
    my $app = shift;
    _set_author_language($app, 'nl');
}

sub _set_author_language {
    my ($app, $language) = @_;
    require MT::Author;
    my @author_ids = $app->param('id');
    for my $author_id (@author_ids) {
        my $author = MT::Author->load($author_id);
        $author->preferred_language($language);
        $author->save;
    }
    $app->redirect( $app->return_uri );
}

1;

