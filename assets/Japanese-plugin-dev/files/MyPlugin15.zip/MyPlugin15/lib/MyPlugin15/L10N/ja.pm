package MyPlugin15::L10N::ja;

use strict;
use base 'MyPlugin15::L10N::en_us';
use vars qw( %Lexicon );

%Lexicon = (
    'Language Japanese' => '使用言語 日本語',
    'Language English' => '使用言語 English',
    'Language Deutsch' => '使用言語 Deutsch',
    'Language Español' => '使用言語 Español',
    'Language Français' => '使用言語 Français',
    'Language Nederlands' => '使用言語 Nederlands',
    'Sample Plugin Add Action' => 'サンプルプラグイン 新規アクション',
    '_PLUGIN_DESCRIPTION' => '新規アクション テストプラグイン',
    '_PLUGIN_AUTHOR' => 'プラグイン作者',
);

1;
