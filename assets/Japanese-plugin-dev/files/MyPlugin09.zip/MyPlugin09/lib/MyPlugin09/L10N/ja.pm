package MyPlugin09::L10N::ja;

use strict;
use base 'MyPlugin09::L10N::en_us';
use vars qw( %Lexicon );

%Lexicon = (
    'Sample Plugin callback' => 'サンプルプラグイン コールバック',
    '_PLUGIN_DESCRIPTION' => 'コールバック テストプラグイン',
    '_PLUGIN_AUTHOR' => 'プラグイン作者',
);

1;
