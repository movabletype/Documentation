package MyPlugin09::Callbacks;
use strict;

sub post_save_entry {
    my ($cb, $app, $obj, $org_obj) = @_;

    my $id = $obj->id;
    my $title = $obj->title;

    eval {
        if (defined($org_obj->id)) {
            doLog("edit entry title ($id): $title");
        }
    };
    if ( $@ ) {
        doLog("save entry title ($id): $title");
    }
}

sub doLog {
    my ($msg, $class) = @_;
    return unless defined($msg);

    require MT::Log;
    my $log = new MT::Log;
    $log->message($msg);
    $log->level(MT::Log::DEBUG());
    $log->class($class) if $class;
    $log->save or die $log->errstr;
}

1;
