package MyPlugin03::L10N::ja;

use strict;
use base 'MyPlugin03::L10N::en_us';
use vars qw( %Lexicon );

%Lexicon = (
    'Sample Plugin Test Driven' => 'サンプルプラグイン テストドリブン',
    '_PLUGIN_DESCRIPTION' => 'テストドリブン テストプラグイン',
    '_PLUGIN_AUTHOR' => 'プラグイン作者',
);

1;
