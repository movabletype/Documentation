package MyPlugin03::Tags;
use strict;

sub _hdlr_hello_world {
    my ($ctx, $args) = @_;

    return "Hello, world!";
}

1;
