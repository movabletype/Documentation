<?php
    function smarty_function_mthelloworld($args, &$ctx) {
        return 'Hello, world!';
    }
?>
