package MyPlugin06::Tags;
use strict;

sub hdlr_categorybreadcrumbs {
    my ($ctx, $args, $cond) = @_;

    my $blog = $ctx->stash('blog') || return;
    my $entry = $ctx->stash('entry')
        || $ctx->error(MT->translate('You used an [_1] tag outside of the proper context.', 'CategoryBreadcrumbs'));
    my $cat = $entry->category() || return _hdlr_top_link($blog);

    my @categories = ();
    while (1){
        if ($cat->parent() == 0) {
            push (@categories, $cat);
            last;
        }
        push (@categories, $cat);
        $cat = MT::Category->load($cat->parent());
    }
    @categories = reverse @categories;

    my $out = _hdlr_top_link($blog);
    for my $category (@categories) {
        local $ctx->{__stash}{category} = $category;

        my $tokens = $ctx->stash('tokens');
        my $builder = $ctx->stash('builder');

        $out .= $builder->build( $ctx, $tokens, $cond)
            || return $ctx->error( $builder->errstr );
    }

    return $out;
}

sub hdlr_categorybreadcrumbtab {
    my ($ctx, $args) = @_;

    my $blog = $ctx->stash('blog') || return;
    my $category = $ctx->stash('category')
        || $ctx->error(MT->translate('You used an [_1] tag outside of the proper context.', 'CategoryBreadcrumbsTab'));

    require MT::Util;
    my $url = $blog->archive_url;
    $url .= '/' unless $url =~ m!/$!;
    $url .= MT::Util::archive_file_for(undef, $blog, 'Category', $category);

    my $count = MT::Placement->count({category_id => $category->id});

    my $anchor_start = '';
    my $anchor_end = '';
    if ( $url && $count ) {
        $anchor_start = '<a href="' . $url . '">';
        $anchor_end = '</a>';
    }

    my $label = $category->label;
    my $out = ' &lt; [ ' . $anchor_start . $label . $anchor_end. ' ]';

    return $out;
}

sub _hdlr_top_link {
    my ($blog) = @_;
    my $blog_url = $blog->archive_url;

    return "[ <a href=\"$blog_url\">Top</a> ]";
}

1;
