package MyPlugin06::L10N;
use strict;
use base 'MT::Plugin::L10N';

1;
