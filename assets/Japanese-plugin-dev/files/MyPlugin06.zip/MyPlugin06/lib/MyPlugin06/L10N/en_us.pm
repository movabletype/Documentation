package MyPlugin06::L10N::en_us;

use strict;
use base 'MyPlugin06::L10N';
use vars qw( %Lexicon );

%Lexicon = (
    '_PLUGIN_DESCRIPTION' => 'Sample block tag',
    '_PLUGIN_AUTHOR' => 'Plugin author',
);

1;
