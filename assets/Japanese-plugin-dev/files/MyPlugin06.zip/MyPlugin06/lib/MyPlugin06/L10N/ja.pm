package MyPlugin06::L10N::ja;

use strict;
use base 'MyPlugin06::L10N::en_us';
use vars qw( %Lexicon );

%Lexicon = (
    'Sample Plugin Block tag' => 'サンプルプラグイン ブロックタグ',
    '_PLUGIN_DESCRIPTION' => 'ブロックタグ テストプラグイン',
    '_PLUGIN_AUTHOR' => 'プラグイン作者',
);

1;
