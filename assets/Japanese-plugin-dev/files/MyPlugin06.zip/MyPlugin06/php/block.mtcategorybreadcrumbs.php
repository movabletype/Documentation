<?php
    function smarty_block_mtcategorybreadcrumbs ($args, $content, &$ctx, &$repeat) {
        $localvars = array('_categories', '_categories_counter', 'category');

        $blog = $ctx->stash('blog');
        if (!$blog) {
            return;
        }
        $entry = $ctx->stash('entry');
        if (!$entry) {
            return;
        }
        $cat = $entry->category();
        if (!$cat) {
            return _hdlr_top_link($blog);
        }

        if (!isset($content)) {
            $ctx->localize($localvars);

            while (1) {
                if ($cat->parent == 0) {
                    $categories[] = $cat;
                    break;
                }
                $categories[] = $cat;
                $category_id = $cat->category_parent;
                $cat = $ctx->mt->db()->fetch_category($category_id);
            }
            $categories = array_reverse($categories);
            $ctx->stash('_categories', $categories);
            $counter = 0;
        } else {
            $categories = $ctx->stash('_categories');
            $counter = $ctx->stash('_categories_counter');
        }


        if ($counter < count($categories)) {
            $category = $categories[$counter];
            $ctx->stash('category', $category);
            $ctx->stash('_categories_counter', $counter + 1);
            $repeat = true;
        } else {
            $ctx->restore($localvars);
            $repeat = false;
        }
        if ($counter == 1) {
            $content = _hdlr_top_link($blog) . $content; 
        }
        return $content;
    }

    function _hdlr_top_link ($blog) {
        $blog_url = $blog->archive_url();

        return "[ <a href=\"$blog_url\">Top</a> ]";
    }
?>
