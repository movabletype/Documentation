<?php
    function smarty_function_mtcategorybreadcrumbtab ($args, &$ctx) {

        $blog = $ctx->stash('blog');
        $category = $ctx->stash('category');

        $args['blog_id'] = $ctx->stash('blog_id');
        if (!$category) return '';
        $url = $ctx->mt->db()->category_link($category->category_id, $args);
        $blog = $ctx->stash('blog');
        $index = $ctx->mt->config('IndexBasename');
        $ext = $blog->blog_file_extension;
        if ($ext) $ext = '.' . $ext; 
        $index .= $ext;
        $url = preg_replace('/\/(#.*)?$/', "/$index\$1", $url);

        $cat_list[] = $category->category_id;
        $placements = $ctx->mt->db()->fetch_placements(array('category_id' => $cat_list));
        if ($placements[0]) {
            $count = 1;
        }

        $anchor_start = '';
        $anchor_end = '';
        if ( $url && $count ) {
            $anchor_start = '<a href="' . $url . '">';
            $anchor_end = '</a>';
        }

        $label = $category->label;
        $out = ' &lt; [ ' . $anchor_start . $label . $anchor_end. ' ]';
 
        return $out;
    }
?>
