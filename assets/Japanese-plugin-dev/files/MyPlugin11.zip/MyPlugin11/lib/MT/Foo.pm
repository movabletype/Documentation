package MT::Foo;
use strict;

use base qw( MT::Object );

__PACKAGE__->install_properties ({
    column_defs => {
        'id'      => 'integer not null auto_increment',
        'blog_id' => 'integer not null',
        'title'   => 'string(255) not null',
        'bar'     => 'text',
    },
    indexes => {
        blog_id => 1,
        created_on => 1,
        modified_on => 1,
    },
    audit => 1,
    datasource  => 'foo',
    primary_key => 'id',
    class_type  => 'foo',
});

1;
