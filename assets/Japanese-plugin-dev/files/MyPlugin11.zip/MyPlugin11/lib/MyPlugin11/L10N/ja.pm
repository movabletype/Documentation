package MyPlugin11::L10N::ja;

use strict;
use base 'MyPlugin11::L10N::en_us';
use vars qw( %Lexicon );

%Lexicon = (
    'Sample Plugin Uniquely Object' => 'サンプルプラグイン 独自オブジェクト',
    '_PLUGIN_DESCRIPTION' => '独自オブジェクト テストプラグイン',
    '_PLUGIN_AUTHOR' => 'プラグイン作者',
);

1;
